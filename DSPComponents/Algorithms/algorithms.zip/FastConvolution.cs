﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;
using DSPAlgorithms.Algorithms;

namespace DSPAlgorithms.Algorithms
{
    public class FastConvolution : Algorithm
    {
        public Signal InputSignal1 { get; set; }
        public Signal InputSignal2 { get; set; }
        public Signal OutputConvolvedSignal { get; set; }

        /// <summary>
        /// Convolved InputSignal1 (considered as X) with InputSignal2 (considered as H)
        /// </summary>
        public override void Run()
        {
            for (int i = 0; i < InputSignal1.Samples.Count; i++)
            {
                float res = InputSignal1.Samples[i] * InputSignal2.Samples[i];
                //InverseDiscreteFourierTransform IDFT = new InverseDiscreteFourierTransform(res);
            }
            //throw new NotImplementedException();
        }
    }
}
